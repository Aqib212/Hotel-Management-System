CREATE TABLE IF NOT EXISTS guestTable (
	fname varchar(500) NOT NULL,
	lname varchar(500) NOT NULL,
	email varchar(500),
	address varchar(500) NOT NULL,
	country varchar(500) NOT NULL,
	mobile varchar(20) NOT NULL,
	id_type varchar(500),
	id varchar(500)
	);
